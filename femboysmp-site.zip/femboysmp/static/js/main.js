// ─── STARS ───────────────────────────────────────────────────────────────────
(function generateStars() {
    const container = document.getElementById('stars');
    if (!container) return;
    const count = 120;
    for (let i = 0; i < count; i++) {
        const star = document.createElement('div');
        star.className = 'star';
        const x = Math.random() * 100;
        const y = Math.random() * 100;
        const dur = 2 + Math.random() * 4;
        const delay = Math.random() * 6;
        const size = Math.random() < 0.2 ? 3 : 2;
        const op = 0.3 + Math.random() * 0.6;
        star.style.cssText = `left:${x}%;top:${y}%;width:${size}px;height:${size}px;
            --dur:${dur}s;--delay:${delay}s;--max-op:${op}`;
        container.appendChild(star);
    }
})();

// ─── NAVBAR SCROLL ───────────────────────────────────────────────────────────
(function navbarScroll() {
    const nav = document.getElementById('navbar');
    if (!nav) return;
    window.addEventListener('scroll', () => {
        nav.classList.toggle('scrolled', window.scrollY > 20);
    }, { passive: true });
})();

// ─── BURGER MENU ─────────────────────────────────────────────────────────────
(function burger() {
    const btn = document.getElementById('navBurger');
    const links = document.getElementById('navLinks');
    if (!btn || !links) return;
    btn.addEventListener('click', () => {
        links.classList.toggle('open');
    });
    document.addEventListener('click', (e) => {
        if (!btn.contains(e.target) && !links.contains(e.target)) {
            links.classList.remove('open');
        }
    });
})();

// ─── COPY IP ──────────────────────────────────────────────────────────────────
function copyIP() {
    const ip = 'mc.femboysmp.ru';
    navigator.clipboard.writeText(ip).then(() => {
        // Hero button
        const heroBtn = document.getElementById('heroIpBtn');
        if (heroBtn) {
            const hint = heroBtn.querySelector('.copy-hint');
            if (hint) {
                hint.textContent = '✓ Скопировано!';
                setTimeout(() => { hint.textContent = 'нажми, чтобы скопировать'; }, 2000);
            }
        }
        // Footer button
        const footerBtn = document.getElementById('ipCopyBtn');
        if (footerBtn) {
            const icon = footerBtn.querySelector('.ip-icon');
            if (icon) {
                icon.textContent = '✓';
                setTimeout(() => { icon.textContent = '⎘'; }, 2000);
            }
        }
    }).catch(() => {
        alert('IP: ' + ip);
    });
}

// ─── FLASH AUTO-HIDE ─────────────────────────────────────────────────────────
(function flashAutoHide() {
    const flashes = document.querySelectorAll('.flash');
    flashes.forEach((f, i) => {
        setTimeout(() => {
            f.style.opacity = '0';
            f.style.transform = 'translateX(20px)';
            f.style.transition = 'opacity .4s, transform .4s';
            setTimeout(() => f.remove(), 400);
        }, 4000 + i * 500);
    });
})();

// ─── SCROLL ANIMATIONS ───────────────────────────────────────────────────────
(function scrollAnimate() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.animationPlayState = 'running';
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });

    document.querySelectorAll('.feature-card, .about-block, .shop-card').forEach((el, i) => {
        const delay = el.dataset.delay ? parseInt(el.dataset.delay) : i * 80;
        el.style.animationDelay = delay + 'ms';
        el.style.animationPlayState = 'paused';
        observer.observe(el);
    });
})();

// ─── FORM SPINNER ─────────────────────────────────────────────────────────────
(function formSpinner() {
    const form = document.getElementById('registerForm');
    if (!form) return;
    form.addEventListener('submit', () => {
        const btn = document.getElementById('submitBtn');
        if (btn) {
            btn.querySelector('.btn-text')?.classList.add('hidden');
            btn.querySelector('.btn-spinner')?.classList.remove('hidden');
            btn.disabled = true;
        }
    });
})();
