from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from flask_mail import Mail, Message
from datetime import datetime, timedelta
import requests
import time
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'femboy_smp_super_secret_key_change_me'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///femboysmp.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Mail config (настрой под свой почтовый сервер)
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'zivan6460@gmail.com'
app.config['MAIL_PASSWORD'] = 'YOUR_APP_PASSWORD'  # Google App Password
app.config['MAIL_DEFAULT_SENDER'] = 'zivan6460@gmail.com'

# Minecraft API config
MC_API_URL = 'http://localhost:8080'
MC_API_KEY = 'femboy_smp_secret_2026'
ADMIN_EMAIL = 'zivan6460@gmail.com'

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Войдите, чтобы продолжить'
mail = Mail(app)


# ─── Модели ──────────────────────────────────────────────────────────────────

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.Text, unique=True, nullable=False)
    password = db.Column(db.Text, nullable=False)
    avatar = db.Column(db.Text, default='avatar1.png')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    purchases = db.relationship('Purchase', backref='user', lazy=True)


class Purchase(db.Model):
    __tablename__ = 'purchases'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    minecraft_nick = db.Column(db.Text, nullable=False)
    email = db.Column(db.Text, nullable=False)
    status = db.Column(db.Text, default='pending')
    whitelist_added = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class WhitelistQueue(db.Model):
    __tablename__ = 'whitelist_queue'
    id = db.Column(db.Integer, primary_key=True)
    purchase_id = db.Column(db.Integer, db.ForeignKey('purchases.id'), nullable=False)
    minecraft_nick = db.Column(db.Text, nullable=False)
    status = db.Column(db.Text, default='pending')
    attempts = db.Column(db.Integer, default=0)
    processed_at = db.Column(db.DateTime)


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


# ─── Утилиты ─────────────────────────────────────────────────────────────────

AVATARS = [f'avatar{i}.png' for i in range(1, 11)]


def add_to_whitelist(nick, retries=3):
    """Добавление в вайтлист с повторными попытками"""
    for attempt in range(retries):
        try:
            resp = requests.post(
                f'{MC_API_URL}/api/whitelist/add',
                json={'nick': nick, 'api_key': MC_API_KEY},
                timeout=5
            )
            if resp.status_code == 200 and resp.json().get('success'):
                return True
        except Exception:
            pass
        if attempt < retries - 1:
            time.sleep(5)
    return False


def get_online_count():
    """Получение онлайна с сервера"""
    try:
        resp = requests.get(f'{MC_API_URL}/api/online', timeout=3)
        if resp.status_code == 200:
            return resp.json().get('online', 0)
    except Exception:
        pass
    return None


# ─── Маршруты ────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    online = get_online_count()
    return render_template('index.html', online=online)


@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/shop')
def shop():
    return render_template('shop.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))

    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        avatar = request.form.get('avatar', 'avatar1.png')

        # Валидация
        if len(username) < 3 or len(username) > 20:
            flash('Логин должен быть от 3 до 20 символов', 'error')
            return render_template('register.html', avatars=AVATARS)
        if len(password) < 8:
            flash('Пароль должен быть не менее 8 символов', 'error')
            return render_template('register.html', avatars=AVATARS)
        if not any(c.isalpha() for c in password) or not any(c.isdigit() for c in password):
            flash('Пароль должен содержать буквы и цифры', 'error')
            return render_template('register.html', avatars=AVATARS)
        if avatar not in AVATARS:
            avatar = 'avatar1.png'
        if User.query.filter_by(username=username).first():
            flash('Этот логин уже занят', 'error')
            return render_template('register.html', avatars=AVATARS)

        hashed = generate_password_hash(password)
        user = User(username=username, password=hashed, avatar=avatar)
        db.session.add(user)
        db.session.commit()
        login_user(user)
        flash('Добро пожаловать на Femboy SMP!', 'success')
        return redirect(url_for('index'))

    return render_template('register.html', avatars=AVATARS)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))

    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        user = User.query.filter_by(username=username).first()

        if user and check_password_hash(user.password, password):
            login_user(user)
            flash(f'Добро пожаловать, {user.username}!', 'success')
            next_page = request.args.get('next')
            return redirect(next_page or url_for('index'))
        flash('Неверный логин или пароль', 'error')

    return render_template('login.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Вы вышли из аккаунта', 'info')
    return redirect(url_for('index'))


@app.route('/profile')
@login_required
def profile():
    return render_template('profile.html', avatars=AVATARS)


@app.route('/profile/change_avatar', methods=['POST'])
@login_required
def change_avatar():
    avatar = request.form.get('avatar')
    if avatar in AVATARS:
        current_user.avatar = avatar
        db.session.commit()
        flash('Аватар обновлён!', 'success')
    else:
        flash('Неверный аватар', 'error')
    return redirect(url_for('profile'))


@app.route('/profile/change_password', methods=['POST'])
@login_required
def change_password():
    old_pw = request.form.get('old_password', '')
    new_pw = request.form.get('new_password', '')
    confirm = request.form.get('confirm_password', '')

    if not check_password_hash(current_user.password, old_pw):
        flash('Старый пароль неверный', 'error')
        return redirect(url_for('profile'))
    if len(new_pw) < 8:
        flash('Новый пароль должен быть не менее 8 символов', 'error')
        return redirect(url_for('profile'))
    if new_pw != confirm:
        flash('Пароли не совпадают', 'error')
        return redirect(url_for('profile'))

    current_user.password = generate_password_hash(new_pw)
    db.session.commit()
    flash('Пароль успешно изменён!', 'success')
    return redirect(url_for('profile'))


@app.route('/buy', methods=['GET', 'POST'])
@login_required
def buy():
    # Защита от спама: 1 покупка в 5 минут с одного IP
    ip = request.remote_addr
    five_min_ago = datetime.utcnow() - timedelta(minutes=5)
    recent = Purchase.query.filter(
        Purchase.user_id == current_user.id,
        Purchase.created_at > five_min_ago
    ).first()
    if recent:
        flash('Подождите 5 минут перед следующей покупкой', 'error')
        return redirect(url_for('shop'))

    if request.method == 'POST':
        mc_nick = request.form.get('minecraft_nick', '').strip()
        email = request.form.get('email', '').strip()
        agree = request.form.get('agree')

        if not mc_nick or not email or not agree:
            flash('Заполните все поля', 'error')
            return render_template('buy.html')

        # Сохраняем покупку
        purchase = Purchase(
            user_id=current_user.id,
            minecraft_nick=mc_nick,
            email=email,
            status='processing'
        )
        db.session.add(purchase)
        db.session.commit()

        # Добавляем в вайтлист
        success = add_to_whitelist(mc_nick)
        if success:
            purchase.status = 'completed'
            purchase.whitelist_added = True
        else:
            # Добавляем в очередь для повторной попытки
            queue_item = WhitelistQueue(
                purchase_id=purchase.id,
                minecraft_nick=mc_nick
            )
            db.session.add(queue_item)
            purchase.status = 'queued'
        db.session.commit()

        # Письма
        try:
            msg_user = Message(
                'Проходка на Femboy SMP',
                recipients=[email]
            )
            msg_user.body = (
                f'Привет, {mc_nick}!\n\n'
                'В течение нескольких минут вы будете добавлены в вайтлист сервера Femboy SMP.\n\n'
                'IP сервера: mc.femboysmp.ru\n\n'
                'Увидимся на сервере!'
            )
            mail.send(msg_user)

            msg_admin = Message(
                f'Новая покупка: {mc_nick}',
                recipients=[ADMIN_EMAIL]
            )
            msg_admin.body = (
                f'Пользователь {current_user.username} купил проходку.\n'
                f'Minecraft ник: {mc_nick}\n'
                f'Email: {email}\n'
                f'Вайтлист добавлен: {"Да" if success else "В очереди"}'
            )
            mail.send(msg_admin)
        except Exception:
            pass  # Письма не обязательны для работы

        flash('Готово! Ты будешь добавлен в вайтлист в течение нескольких минут.', 'success')
        return redirect(url_for('index'))

    return render_template('buy.html')


# ─── API для фронтенда ────────────────────────────────────────────────────────

@app.route('/api/online')
def api_online():
    count = get_online_count()
    return jsonify({'online': count, 'available': count is not None})


@app.route('/api/avatars')
def api_avatars():
    return jsonify({'avatars': AVATARS})


# ─── Init ─────────────────────────────────────────────────────────────────────

with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80, debug=False)
