from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from flask_mail import Mail, Message
from datetime import datetime, timedelta
from PIL import Image
import requests, time, os, random, string, io

try:
    from mcstatus import JavaServer
    MCSTATUS_AVAILABLE = True
except ImportError:
    MCSTATUS_AVAILABLE = False

app = Flask(__name__)
app.config['SECRET_KEY'] = 'femboy_smp_super_secret_key_change_me'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///femboysmp.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024  # 5MB макс

# Mail — вставь свой Google App Password
app.config['MAIL_SERVER']   = 'smtp.gmail.com'
app.config['MAIL_PORT']     = 587
app.config['MAIL_USE_TLS']  = True
app.config['MAIL_USERNAME'] = 'zivan6460@gmail.com'
app.config['MAIL_PASSWORD'] = 'YOUR_APP_PASSWORD'
app.config['MAIL_DEFAULT_SENDER'] = 'zivan6460@gmail.com'

MC_API_URL   = 'http://localhost:8080'
MC_API_KEY   = 'femboy_smp_secret_2026'
ADMIN_EMAIL  = 'zivan6460@gmail.com'
ROOT_LOGIN   = 'root'
ROOT_PASSWORD = 'KxTpLmRqNs'

UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'static', 'images', 'avatars')
ALLOWED_EXT   = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

BANNED_USERNAMES = {
    'admin', 'administrator', 'aux', 'con', 'prn', 'nul',
    'com1', 'com2', 'com3', 'com4', 'lpt1', 'lpt2',
    'system', 'superuser', 'sysadmin', 'moderator', 'moder', 'mod',
    'owner', 'server', 'minecraft', 'support', 'help', 'info',
    'postmaster', 'webmaster', 'hostmaster', 'null', 'undefined',
    'test', 'guest', 'user', 'nobody', 'daemon', 'operator',
}

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Войдите, чтобы продолжить'
mail = Mail(app)


# ─── Модели ──────────────────────────────────────────────────────────────────

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id         = db.Column(db.Integer, primary_key=True)
    username   = db.Column(db.Text, unique=True, nullable=False)
    email      = db.Column(db.Text, unique=True, nullable=False)
    password   = db.Column(db.Text, nullable=False)
    avatar     = db.Column(db.Text, default='default.png')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    purchases  = db.relationship('Purchase', backref='user', lazy=True)


class Purchase(db.Model):
    __tablename__ = 'purchases'
    id             = db.Column(db.Integer, primary_key=True)
    user_id        = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    minecraft_nick = db.Column(db.Text, nullable=False)
    email          = db.Column(db.Text, nullable=False)
    status         = db.Column(db.Text, default='pending')
    whitelist_added = db.Column(db.Boolean, default=False)
    created_at     = db.Column(db.DateTime, default=datetime.utcnow)


class WhitelistQueue(db.Model):
    __tablename__ = 'whitelist_queue'
    id             = db.Column(db.Integer, primary_key=True)
    purchase_id    = db.Column(db.Integer, db.ForeignKey('purchases.id'), nullable=False)
    minecraft_nick = db.Column(db.Text, nullable=False)
    status         = db.Column(db.Text, default='pending')
    attempts       = db.Column(db.Integer, default=0)
    processed_at   = db.Column(db.DateTime)


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


# ─── Утилиты ─────────────────────────────────────────────────────────────────

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXT


def save_avatar(file_storage, username):
    """Сохраняет аватар, обрезает до квадрата 256x256"""
    try:
        img = Image.open(file_storage.stream).convert('RGBA')
        # Обрезаем до квадрата по центру
        w, h = img.size
        side = min(w, h)
        left = (w - side) // 2
        top  = (h - side) // 2
        img = img.crop((left, top, left + side, top + side))
        img = img.resize((256, 256), Image.LANCZOS)
        # Сохраняем как PNG
        filename = f'user_{username}_{int(time.time())}.png'
        path = os.path.join(UPLOAD_FOLDER, filename)
        img.save(path, 'PNG')
        return filename
    except Exception as e:
        print(f'Avatar save error: {e}')
        return None


def generate_code():
    return ''.join(random.choices(string.digits, k=6))


def send_confirm_email(email, code):
    try:
        msg = Message('Подтверждение регистрации — Femboy SMP', recipients=[email])
        msg.body = (
            f'Твой код подтверждения: {code}\n\n'
            f'Введи его на странице регистрации.\n'
            f'Код действителен 10 минут.\n\n'
            f'Если ты не регистрировался — просто игнорируй это письмо.\n\n'
            f'— Femboy SMP'
        )
        msg.html = f'''
        <div style="font-family:sans-serif;max-width:400px;margin:0 auto;background:#0d0d1f;color:#e8e8f5;padding:2rem;border-radius:16px;border:1px solid rgba(212,127,255,0.2)">
            <h2 style="color:#d47fff;margin-bottom:1rem">Femboy SMP</h2>
            <p>Твой код подтверждения регистрации:</p>
            <div style="font-size:2.5rem;font-weight:900;letter-spacing:.3em;color:#55ffff;background:rgba(85,255,255,0.1);border:1px solid rgba(85,255,255,0.3);border-radius:12px;padding:1rem;text-align:center;margin:1.5rem 0">{code}</div>
            <p style="color:rgba(232,232,245,0.5);font-size:.85rem">Код действителен 10 минут.</p>
            <p style="color:rgba(232,232,245,0.5);font-size:.85rem">Не нашёл письмо? <strong style="color:#d47fff">Проверь папку «Спам»</strong></p>
        </div>
        '''
        mail.send(msg)
        return True
    except Exception as e:
        print(f'Mail error: {e}')
        return False


def get_online_count():
    if not MCSTATUS_AVAILABLE:
        return None
    try:
        server = JavaServer.lookup('mc.femboysmp.ru:25565')
        return server.status().players.online
    except Exception:
        return None


def add_to_whitelist(nick, retries=3):
    for attempt in range(retries):
        try:
            resp = requests.post(
                f'{MC_API_URL}/api/whitelist/add',
                json={'nick': nick, 'api_key': MC_API_KEY},
                timeout=5
            )
            if resp.status_code == 200 and resp.json().get('success'):
                return True
        except Exception:
            pass
        if attempt < retries - 1:
            time.sleep(5)
    return False


# ─── Маршруты ────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    return render_template('index.html', online=get_online_count())

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/shop')
def shop():
    return render_template('shop.html')


# ─── РЕГИСТРАЦИЯ ─────────────────────────────────────────────────────────────

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    return render_template('register.html', username='', email='', step='form')


@app.route('/register/send_code', methods=['POST'])
def register_send_code():
    """Регистрация — сразу создаём аккаунт без подтверждения почты"""
    username = request.form.get('username', '').strip().lower()
    email    = request.form.get('email', '').strip().lower()
    password = request.form.get('password', '').strip()
    avatar_file = request.files.get('avatar')

    def back(msg):
        flash(msg, 'error')
        return render_template('register.html', username=username, email=email, step='form')

    # root — особый случай
    if username == ROOT_LOGIN:
        if password != ROOT_PASSWORD:
            return back('Неверный пароль для этого логина')
        if '@' not in email or '.' not in email.split('@')[-1]:
            return back('Введи корректный email')
        if User.query.filter_by(username=ROOT_LOGIN).first():
            return back('Этот логин уже занят')
        if User.query.filter_by(email=email).first():
            return back('Этот email уже используется')
        avatar_filename = 'default.png'
        if avatar_file and avatar_file.filename and allowed_file(avatar_file.filename):
            saved = save_avatar(avatar_file, ROOT_LOGIN)
            if saved:
                avatar_filename = saved
        user = User(username=ROOT_LOGIN, email=email,
                    password=generate_password_hash(password),
                    avatar=avatar_filename)
        db.session.add(user)
        db.session.commit()
        login_user(user)
        flash('Добро пожаловать, root!', 'success')
        return redirect(url_for('index'))

    # Валидация
    if len(username) < 3 or len(username) > 20:
        return back('Логин должен быть от 3 до 20 символов')
    if not username.replace('_', '').replace('-', '').isalnum():
        return back('Логин может содержать только буквы, цифры, _ и -')
    if username in BANNED_USERNAMES:
        return back('Этот логин зарезервирован, выбери другой')
    if '@' not in email or '.' not in email.split('@')[-1]:
        return back('Введи корректный email')
    if len(password) < 8:
        return back('Пароль должен быть не менее 8 символов')
    if not any(c.isalpha() for c in password) or not any(c.isdigit() for c in password):
        return back('Пароль должен содержать буквы и цифры')
    if User.query.filter_by(username=username).first():
        return back('Этот логин уже занят')
    if User.query.filter_by(email=email).first():
        return back('Этот email уже зарегистрирован')

    # Аватар
    avatar_filename = 'default.png'
    if avatar_file and avatar_file.filename and allowed_file(avatar_file.filename):
        saved = save_avatar(avatar_file, username)
        if saved:
            avatar_filename = saved
        else:
            return back('Не удалось обработать фото. Попробуй другой файл.')

    # Сразу создаём аккаунт
    user = User(username=username, email=email,
                password=generate_password_hash(password),
                avatar=avatar_filename)
    db.session.add(user)
    db.session.commit()
    login_user(user)
    flash('Добро пожаловать на Femboy SMP!', 'success')
    return redirect(url_for('index'))


@app.route('/register/confirm', methods=['POST'])
def register_confirm():
    """Шаг 2: проверка кода и создание аккаунта"""
    pending = session.get('pending_reg')
    entered_code = request.form.get('code', '').strip()

    if not pending:
        flash('Сессия истекла. Начни регистрацию заново.', 'error')
        return redirect(url_for('register'))

    expires = datetime.fromisoformat(pending['expires'])
    if datetime.utcnow() > expires:
        session.pop('pending_reg', None)
        flash('Код истёк. Зарегистрируйся заново.', 'error')
        return redirect(url_for('register'))

    if entered_code != pending['code']:
        attempts = pending.get('attempts', 0) + 1
        pending['attempts'] = attempts
        session['pending_reg'] = pending
        if attempts >= 5:
            session.pop('pending_reg', None)
            flash('Слишком много неверных попыток. Начни заново.', 'error')
            return redirect(url_for('register'))
        flash(f'Неверный код. Осталось попыток: {5 - attempts}', 'error')
        return render_template('register.html',
                               username=pending['username'],
                               email=pending['email'],
                               step='confirm')

    # Код верный — создаём аккаунт
    if User.query.filter_by(username=pending['username']).first() or \
       User.query.filter_by(email=pending['email']).first():
        session.pop('pending_reg', None)
        flash('Этот логин или email уже занят.', 'error')
        return redirect(url_for('register'))

    user = User(
        username=pending['username'],
        email=pending['email'],
        password=pending['password'],
        avatar=pending['avatar']
    )
    db.session.add(user)
    db.session.commit()
    session.pop('pending_reg', None)
    login_user(user)
    flash('Добро пожаловать на Femboy SMP!', 'success')
    return redirect(url_for('index'))


@app.route('/register/resend_code', methods=['POST'])
def register_resend_code():
    """Повторная отправка кода"""
    pending = session.get('pending_reg')
    if not pending:
        return redirect(url_for('register'))
    code = generate_code()
    pending['code'] = code
    pending['expires'] = (datetime.utcnow() + timedelta(minutes=10)).isoformat()
    pending['attempts'] = 0
    session['pending_reg'] = pending
    sent = send_confirm_email(pending['email'], code)
    if sent:
        flash('Новый код отправлен. Проверь папку Спам если не видишь письма.', 'info')
    else:
        flash('Не удалось отправить. Попробуй позже.', 'error')
    return render_template('register.html',
                           username=pending['username'],
                           email=pending['email'],
                           step='confirm')


# ─── ЛОГИН ───────────────────────────────────────────────────────────────────

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))

    if request.method == 'POST':
        login_input = request.form.get('username', '').strip()
        password    = request.form.get('password', '').strip()

        # root
        if login_input.lower() == ROOT_LOGIN and password == ROOT_PASSWORD:
            user = User.query.filter_by(username=ROOT_LOGIN).first()
            if not user:
                user = User(username=ROOT_LOGIN, email='root@femboysmp.ru',
                            password=generate_password_hash(ROOT_PASSWORD))
                db.session.add(user)
                db.session.commit()
            login_user(user)
            flash('Добро пожаловать, root!', 'success')
            return redirect(url_for('index'))

        user = User.query.filter_by(username=login_input.lower()).first()
        if not user:
            user = User.query.filter_by(email=login_input.lower()).first()

        if user and check_password_hash(user.password, password):
            login_user(user)
            flash(f'Добро пожаловать, {user.username}!', 'success')
            return redirect(request.args.get('next') or url_for('index'))
        flash('Неверный логин или пароль', 'error')

    return render_template('login.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Вы вышли из аккаунта', 'info')
    return redirect(url_for('index'))


# ─── ПРОФИЛЬ ─────────────────────────────────────────────────────────────────

@app.route('/profile')
@login_required
def profile():
    return render_template('profile.html')


@app.route('/profile/change_avatar', methods=['POST'])
@login_required
def change_avatar():
    avatar_file = request.files.get('avatar')
    if not avatar_file or not avatar_file.filename:
        flash('Выбери файл', 'error')
        return redirect(url_for('profile'))
    if not allowed_file(avatar_file.filename):
        flash('Только PNG, JPG, GIF, WEBP', 'error')
        return redirect(url_for('profile'))

    # Удаляем старый аватар если не дефолтный
    if current_user.avatar and current_user.avatar != 'default.png':
        old_path = os.path.join(UPLOAD_FOLDER, current_user.avatar)
        if os.path.exists(old_path):
            try:
                os.remove(old_path)
            except Exception:
                pass

    saved = save_avatar(avatar_file, current_user.username)
    if not saved:
        flash('Не удалось обработать фото', 'error')
        return redirect(url_for('profile'))

    current_user.avatar = saved
    db.session.commit()
    flash('Аватар обновлён!', 'success')
    return redirect(url_for('profile'))


@app.route('/profile/change_password', methods=['POST'])
@login_required
def change_password():
    old_pw  = request.form.get('old_password', '')
    new_pw  = request.form.get('new_password', '')
    confirm = request.form.get('confirm_password', '')

    if not check_password_hash(current_user.password, old_pw):
        flash('Старый пароль неверный', 'error')
        return redirect(url_for('profile'))
    if len(new_pw) < 8:
        flash('Новый пароль должен быть не менее 8 символов', 'error')
        return redirect(url_for('profile'))
    if new_pw != confirm:
        flash('Пароли не совпадают', 'error')
        return redirect(url_for('profile'))

    current_user.password = generate_password_hash(new_pw)
    db.session.commit()
    flash('Пароль успешно изменён!', 'success')
    return redirect(url_for('profile'))


# ─── МАГАЗИН ─────────────────────────────────────────────────────────────────

@app.route('/buy', methods=['GET', 'POST'])
@login_required
def buy():
    # Проверяем есть ли уже покупка вообще (не только за 5 минут)
    already = Purchase.query.filter_by(user_id=current_user.id).first()
    if already:
        flash(f'Ты уже получил проходку для ника {already.minecraft_nick}!', 'info')
        return redirect(url_for('index'))

    if request.method == 'POST':
        mc_nick = request.form.get('minecraft_nick', '').strip()

        if not mc_nick:
            flash('Введи свой никнейм в Minecraft', 'error')
            return render_template('buy.html')

        email = current_user.email  # берём из аккаунта

        purchase = Purchase(user_id=current_user.id, minecraft_nick=mc_nick,
                            email=email, status='processing')
        db.session.add(purchase)
        db.session.commit()

        success = add_to_whitelist(mc_nick)
        if success:
            purchase.status = 'completed'
            purchase.whitelist_added = True
        else:
            queue_item = WhitelistQueue(purchase_id=purchase.id, minecraft_nick=mc_nick)
            db.session.add(queue_item)
            purchase.status = 'queued'
        db.session.commit()

        try:
            msg = Message('Проходка на Femboy SMP', recipients=[email])
            msg.body = (f'Привет, {mc_nick}!\n\n'
                        'В течение нескольких минут ты будешь добавлен в вайтлист.\n'
                        'IP: mc.femboysmp.ru\n\nДо встречи!')
            mail.send(msg)
            msg2 = Message(f'Новая покупка: {mc_nick}', recipients=[ADMIN_EMAIL])
            msg2.body = (f'Пользователь {current_user.username}\n'
                         f'Ник: {mc_nick}\nEmail: {email}\n'
                         f'Вайтлист: {"Да" if success else "В очереди"}')
            mail.send(msg2)
        except Exception:
            pass

        flash('Готово! Ты будешь добавлен в вайтлист в течение нескольких минут.', 'success')
        return redirect(url_for('index'))

    return render_template('buy.html')


# ─── API ─────────────────────────────────────────────────────────────────────

@app.route('/api/online')
def api_online():
    count = get_online_count()
    return jsonify({'online': count, 'available': count is not None})


# ─── Init ─────────────────────────────────────────────────────────────────────

with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80, debug=False)
