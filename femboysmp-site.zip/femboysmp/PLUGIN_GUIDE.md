# 🔌 ГАЙД: HTTP API для Paper-сервера (Femboy SMP)

## Какой плагин ставить?

Для Paper-сервера рекомендую **RestfulMC** или **WebAPI** — но самый простой и надёжный вариант
для твоих задач (онлайн + вайтлист) — это **HttpAPIBukkit** или его альтернатива **PaperMC Web API**.

**Конкретная рекомендация: используй плагин `RestfulMC`**
- Поддерживает Paper 1.20+
- Есть эндпоинты для онлайна и вайтлиста из коробки
- Ссылка: https://modrinth.com/plugin/restfulmc

---

## ВАРИАНТ 1 — RestfulMC (рекомендую)

### Установка:

1. Скачай `.jar` с https://modrinth.com/plugin/restfulmc
2. Останови сервер: `stop`
3. Положи `RestfulMC-X.X.X.jar` в папку `plugins/`
4. Запусти сервер — плагин создаст `plugins/RestfulMC/config.yml`
5. Отредактируй конфиг:

```yaml
# plugins/RestfulMC/config.yml
server:
  port: 8080
  host: 0.0.0.0

security:
  api-key: "femboy_smp_secret_2026"
  enabled: true
```

6. Перезапусти сервер: `reload` или `restart`

### Проверка:
```bash
curl http://localhost:8080/api/v1/server/players
```

---

## ВАРИАНТ 2 — Написать свой мини-плагин (если готовые не подходят)

Если RestfulMC не встаёт или не то — вот минимальный плагин на Python-скрипте через RCON.

### Используй RCON вместо плагина:

RCON — встроенный протокол управления сервером. Не нужен никакой плагин!

**1. Включи RCON в `server.properties`:**
```properties
enable-rcon=true
rcon.port=25575
rcon.password=femboy_rcon_2026
```

**2. Установи Python-библиотеку mcrcon на VPS:**
```bash
pip3 install mcrcon
```

**3. В `app.py` добавь функцию добавления в вайтлист через RCON:**
```python
from mcrcon import MCRcon

RCON_HOST = 'localhost'
RCON_PORT = 25575
RCON_PASSWORD = 'femboy_rcon_2026'

def add_to_whitelist_rcon(nick):
    try:
        with MCRcon(RCON_HOST, RCON_PASSWORD, port=RCON_PORT) as mcr:
            result = mcr.command(f'whitelist add {nick}')
            return 'Added' in result or 'already' in result.lower()
    except Exception as e:
        print(f'RCON error: {e}')
        return False
```

**4. Для онлайна — используй query протокол:**
```bash
pip3 install mcstatus
```

В `server.properties`:
```properties
enable-query=true
query.port=25565
```

В `app.py`:
```python
from mcstatus import JavaServer

def get_online_count():
    try:
        server = JavaServer.lookup('localhost:25565')
        status = server.status()
        return status.players.online
    except Exception:
        return None
```

---

## РЕКОМЕНДУЮ ИТОГОВЫЙ СТЕК:

| Задача | Способ | Установка |
|--------|--------|-----------|
| Онлайн игроков | mcstatus (query) | `pip3 install mcstatus` |
| Добавление в вайтлист | RCON | `pip3 install mcrcon` |

Это **не требует никаких плагинов** — только включить RCON и Query в `server.properties`.

---

## Пошаговая инструкция (RCON + mcstatus):

```bash
# На VPS:
pip3 install mcrcon mcstatus
```

В `server.properties` на Minecraft-сервере:
```properties
enable-rcon=true
rcon.port=25575
rcon.password=ТВОЙ_ПАРОЛЬ_RCON

enable-query=true
query.port=25565
```

Перезапусти Minecraft-сервер.

Замени в `app.py` функции `add_to_whitelist` и `get_online_count` на версии с RCON/mcstatus из этого гайда.

---

## Проверка что всё работает:

```bash
# Проверить онлайн:
python3 -c "from mcstatus import JavaServer; s=JavaServer.lookup('localhost'); print(s.status().players.online)"

# Проверить RCON:
python3 -c "from mcrcon import MCRcon; mcr=MCRcon('localhost','ТВОЙ_ПАРОЛЬ'); mcr.connect(); print(mcr.command('list')); mcr.disconnect()"
```
